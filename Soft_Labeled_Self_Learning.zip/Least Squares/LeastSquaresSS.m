%% Semi-Supervised Least Squares Classification. The Initilization of the
% Dataset should be done with X, and the set of Labels with L
if exist('Sets')==0
    Sizeset=1;
else
    [~,Sizeset]=size(Sets);
end

neg=zeros(3,Sizeset); 
MAI_table=zeros(3,Sizeset) ;
Risk_table=zeros(3,Sizeset);         
Risk_Acc_Sup=zeros(Sizeset,2);   

for setnumber=1:Sizeset
    if exist('Sets')==1
    load(Sets{setnumber});
    else
        Sets={'Results'};
    end
if exist('n') ==0
    n=input('Number of labeled samples?;');       % #Labeled points
end
if exist('m') ==0
    m=input('Number of unlabeled samples?;');       % #unlabeled points
end
R=1000;    %  #Test rounds
h=0;
rng(s);   % The rng seed that was used

L=L-min(L)+1;  %Resc the lables


Test=[0.1 1 1];   %Variable of the Semi-Supervised Method
[X_val,X_dim]=size(X);
X2=[X ones(X_val,1)];
[~,Size]=size(Test);
 % Vectors of results:
        MAI=zeros(R,Size);           
        Risk=zeros(R,Size);
        Risk_Acc=zeros(R,2);
        

  
for k=1:R   %Loop over the # of test rounds
%%  Initializing the Labeled and Unlabeled Training set and the Test set 
  % After this section..
  % the labeled Trainingset is stored in TrainL (Training_Labeled)
  % the unlabeled Trainingset is stored in TrainU (Training_Unlabeled)
  % the Testset is stored in TestS     (Test_Set)
  
ind1=find((1==L));  
ind2=find((2==L));
indLone=datasample(ind1,1)';
indLtwo=datasample(ind2,1)';
YTrainLn=datasample(setdiff([1:1:X_val],[indLone; indLtwo]),n-2,'Replace',false)';
YTrainL1=[YTrainLn; indLone; indLtwo];
indU=datasample(setdiff([1:1:X_val],YTrainL1),m,'Replace',false)';
indT=setdiff([1:1:X_val],[YTrainL1; indU])';
TrainL=X2(YTrainL1,:);
TrainU=X2(indU,:);
t=X_val-m-n;
TestS=X2(indT,:);
YU=L(indU);
YTest=L(indT);
YTrainL=L(YTrainL1);

%%  Initializing the only supervised Linear classifier with least squares 
 L1=zeros(m,2);  %Vector of future soft/hard labels
 z=inv((TrainL'*TrainL))*TrainL'*YTrainL; 
 
 %% Creating hard and soft labels
for q=Test;
      h=h+1  ; 
 if h==Size
    for i=1:m   % Creating hard labels 
        L1(i,1)=round((((TrainU(i,:)*z-2)^(2)))^q/...
        ((((TrainU(i,:)*z-1)^(2)))^q+(((TrainU(i,:)*z-2)^(2)))^q));
        L1(i,2)=round((((TrainU(i,:)*z-1)^(2)))^q/...
        ((((TrainU(i,:)*z-1)^(2)))^q+(((TrainU(i,:)*z-2)^(2)))^q));
    end
    
  else
          
    for i=1:m   % Creating soft labels
        
        L1(i,1)=(((TrainU(i,:)*z-2)^(2)))^q/...
        ((((TrainU(i,:)*z-1)^(2)))^q+(((TrainU(i,:)*z-2)^(2)))^q);
    
        L1(i,2)=(((TrainU(i,:)*z-1)^(2)))^q/...
        ((((TrainU(i,:)*z-1)^(2)))^q+(((TrainU(i,:)*z-2)^(2)))^q);
    end
          
 end
     
K=[TrainL ; TrainU ];  % Matrix of labeld + unlabeled points
%Initializing the semi-supervised Linear classifier proposed by expectation
%minimization
z2=inv((K'*K))*(TrainL'*YTrainL+1*TrainU'*L1(:,1)+2*TrainU'*(L1(:,2)));

% Misclassification Vector supervised classifier:
A=sign((TestS*z)-1.5*ones(t,1))==sign(YTest-1.5*ones(t,1));  
% Misclassification Vector semii:supervised classifier:
B=sign((TestS*z2)-1.5*ones(t,1))==sign(YTest-1.5*ones(t,1));   



% Accuracy difference: Semisupervised Accuracy - Supervised Accuracy:
MAI(k,h)=(sum(B))/(t)- (sum(A))/(t);
% Mean Squared Error on the Testset of the semi-supervised method:
Risk(k,h)=1/t*sum(((TestS*z2-YTest).^2));


end
h=0;
% Mean Squared Error and Accuracy on the Testset of the supervised method:
 Risk_Acc(k,:)=[1/t*sum(((TestS*z-YTest).^2)) (sum(A))/(t)];


end
ACCsup=sum(Risk_Acc(:,2))/R;
Risk_Sup=sum(Risk_Acc(:,1))/R;    
neg(:,setnumber)=(sum(sign(MAI)==sign(-1))/R)'; 
MAI_table(:,setnumber)=(sum(MAI)/R)' ;
Risk_table(:,setnumber)=(sum(Risk)/R)';         
Risk_Acc_Sup(setnumber,:)=[Risk_Sup ACCsup];          

end
table(neg(1,:)',MAI_table(1,:)',Risk_table(1,:)',neg(2,:)',MAI_table(2,:)',Risk_table(2,:)',neg(3,:)',...
    MAI_table(3,:)',Risk_table(3,:)',Risk_Acc_Sup(:,1),Risk_Acc_Sup(:,2),'VariableNames',...
 {'neg01' 'MAI01' 'Risk01' 'neg1' 'MAI1' 'Risk1' 'negH' 'MAIH' 'RiskH' 'RiskS' 'AccS'},...
 'RowNames',Sets)
clear Sets;


