%% Semi-Supervised version of a Nearest Mean classifier by expectation minimization

if exist('Sets')==0
    Sizeset=1;
else
    [~,Sizeset]=size(Sets);
end

neg=zeros(3,Sizeset); 
MAI_table=zeros(3,Sizeset) ;
Risk_table=zeros(3,Sizeset);         
Risk_Acc_Sup=zeros(Sizeset,2); 

for setnumber=1:Sizeset
      if exist('Sets')==1
    load(Sets{setnumber});
    else
        Sets={'Results'};
    end

if exist('n') ==0
    n=input('Number of labeled samples?;');       % #Labeled points
end
if exist('m') ==0
    m=input('Number of unlabeled samples?;');       % #unlabeled points
end
                 
Test=[0.1 1 1 ];  % Parameter values for the posterior computation. The last setting will always be transformed to a hard label
L=L-min(L);
rng(s);
[~,Size]=size(Test);   
R=1000;            % #Testruns
% Vectors of Results
MAI=zeros(R,Size);
Risk=zeros(R,Size);
Risk_Sup=zeros(R,1);
Acc_Sup=zeros(R,1);

for k=1:R

[X_val,X_dim]=size(X);               
h=0;      %Counter for the 3 parameter settings of Test


m0new=zeros(Size,X_dim);
m1new=zeros(Size,X_dim);


   

%%  Initializing the Labeled/Unlabed Trainingset (Train/U) and the Testset (TestS)
ind0=find((0==L));
ind1=find((1==L));
indLzero=datasample(ind0,1)';
indLone=datasample(ind1,1)';
YTrainLn=datasample(setdiff([1:1:X_val],[indLzero; indLone]),n-2,'Replace',false)';
YTrainL=[YTrainLn; indLzero; indLone];
indU=datasample(setdiff([1:1:X_val],YTrainL),m,'Replace',false)';
indT=setdiff([1:1:X_val],[YTrainL; indU])';
TrainL0=find((0==L(YTrainL)));
TrainL1=find((1==L(YTrainL)));
LabU=L(indU);
U=X(indU,:);
t=X_val-m-n;
TestS=X(indT,:);
YTest=L(indT);
Train=X(YTrainL,:);


%% Storing the Vector of the soft labels in L1 and the supervised found means in m0 and m1
L1=zeros(m,2);  

sum0=sum(X(YTrainL(TrainL0),:),1);
sum1=sum(X(YTrainL(TrainL1),:),1);
card0=length(TrainL0);
card1=length(TrainL1);
m0=1/card0.*sum0;           
m1=1/card1.*sum1;

for q=Test;
    h=h+1;
    if h==Size
        for i=1:m                       % Creating hard labels
            norm1=(norm(U(i,:)-m0));
            norm2=(norm(U(i,:)-m1));
            L1(i,1)=round(((norm2)^q/((norm1)^q+(norm2)^q)));
            L1(i,2)=round(((norm1)^q/((norm1)^q+(norm2)^q)));
        end
    else

        for i=1:m                       % Creating soft labels
            norm1=(norm(U(i,:)-m0));
            norm2=(norm(U(i,:)-m1));
            L1(i,1)=((norm2)^q/((norm1)^q+(norm2)^q));
            L1(i,2)=((norm1)^q/((norm1)^q+(norm2)^q));
        end
    end    
    
%% Storing the semi-supervised found means in m0new and m1new

SemiL1=L1(:,1)'*U;
SemiL2=L1(:,2)'*U;

m0new(h,:)=1/(card0+sum(L1(:,1))).*(sum0+SemiL1);
m1new(h,:)=(sum1+SemiL2)./(card1+sum(L1(:,2)));

%% Storing the label prediction of the semi-supervised classifier in I2 and of the supervised classifier in I
A=zeros(t,2);
B=zeros(t,2);
                                  
G1=TestS-repmat(m0,[t,1]);
G2=TestS-repmat(m1,[t,1]);
G1new=TestS-repmat(m0new(h,:),[t,1]);
G2new=TestS-repmat(m1new(h,:),[t,1]);
    
A = [sum(G1.^2,2) sum(G2.^2,2)];
B = [sum(G1new.^2,2) sum(G2new.^2,2)];

[~,I]=min(A');
[~,I2]=min(B');

A1=I'-1==YTest;                % Misclassification Vector
B1=I2'-1==YTest;  

%% Storing the results..
% .. S stores the classification accuracy difference between the
% semi-supervised and the supervised classifier
% .. Acc_Sup stores the accuracy of the supervised classifier
% .. S1 stores the risk on the testset of the semi-supervised classifier
% .. S2 stores the risk on the testset of the supervised classifier
MAI(k,h)=(sum(B1))/(t)- (sum(A1))/(t);
 Risk(k,h)=YTest'*((sum((TestS-repmat(m1new(h,:),[t,1])).^2,2)).^(1/2))...
    +(1-YTest')*((sum((TestS-repmat(m0new(h,:),[t,1])).^2,2)).^(1/2));
   
end
Risk_Sup(k)=YTest'*((sum((TestS-repmat(m1,[t,1])).^2,2)).^(1/2))...
+(1-YTest')*((sum((TestS-repmat(m0,[t,1])).^2,2)).^(1/2));

 h=0;
Acc_Sup(k)=(sum(A1))/(t);

end
Acc_Sup=sum(Acc_Sup)/R;
Risk=Risk/t;
Risk_Sup=Risk_Sup/t;
neg(:,setnumber)=(sum(sign(MAI)==sign(-1))/R)'; 
MAI_table(:,setnumber)=(sum(MAI)/R)' ;
Risk_table(:,setnumber)=(sum(Risk)/R)';
Risk_Sup=sum(Risk_Sup)/R;             
Risk_Acc_Sup(setnumber,:)=[Risk_Sup Acc_Sup];           

end
table(neg(1,:)',MAI_table(1,:)',Risk_table(1,:)',neg(2,:)',MAI_table(2,:)',Risk_table(2,:)',neg(3,:)',...
    MAI_table(3,:)',Risk_table(3,:)',Risk_Acc_Sup(:,1),Risk_Acc_Sup(:,2),'VariableNames',...
 {'neg01' 'MAI01' 'Risk01' 'neg1' 'MAI1' 'Risk1' 'negH' 'MAIH' 'RiskH' 'RiskS' 'AccS'},...
 'RowNames',Sets)
clear 'Sets';